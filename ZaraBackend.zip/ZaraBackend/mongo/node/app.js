var express = require("express");
var app = express();
app.get("/landing", (req, res) => {
  res.send("hello mehdi");
});
var port = process.env.PORT || 3000;
app.listen(port, () => console.log(`sdlistening on port ${port}`));
